from automate import Automate
from state import State
from transition import Transition
from myparser import *
#automate = Automate.creationAutomate("exempleAutomate.txt")
#automate.show("exempleAutomate")

#Creation des etats de l'automate
s0= State(0, True, False)
s1= State(1, False, False)
s2= State(2, False, True)

#creation des transition de A
t1 = Transition(s0, "a", s0)
t2 = Transition(s0, "b", s1)
t3 = Transition(s1, "a", s2)
t4 = Transition(s1, "b", s2)
t5 = Transition(s2, "a", s0)
t6 = Transition(s2, "b", s1)
#Creation de la liste de transition
liste = [t1,t2,t3,t4,t5,t6]
#Creation d'un automate a partir de la liste uniquement
auto = Automate(liste)
print(auto)
auto.show("A_ListeTrans")
entrauto
#Creation d'automate a partir d'une liste de transition et d'etats
Auto1 : Automate
auto1 = Automate(listTransitions =  [t1,t2,t3,t4,t5,t6], listStates =  [s0,s1,s2], label = "B")
print(auto1)
auto.show("B")


#Creation d'un automate a partir d'un fichier txt
auto2 = Automate.creationAutomate("auto.txt")
print(auto2)
auto.show("auto.txt")

#Remove une transition :
t = Transition(s0, "a", s1)
print("La transition t a t'elle ete supprime ?", auto.removeTransition(t))
print("La transition t1 a t'elle ete supprime? ", auto.removeTransition(t1))

#Ajouter une transition:
auto.addTransition(t1)
print("La transition a t'elle ete rajouté?", auto.addTransition(t1))

#Retirer un etat
print("L'etat s1 a t'il ete supprime? ", auto.removeState(s1))
#Ajouter un etat
print("L'etat s1 a t'il ete ajouté ?",auto.addState(s1))
print("L'etat s2 a t'il ete ajouté ?",auto.addState(s2))

#Appeler la fonction qui permet d'obtenir la liste de transition
print("\t")
print(auto1.getListTransitionsFrom(s1),"\t")
