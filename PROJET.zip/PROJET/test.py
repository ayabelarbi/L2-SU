# -*- coding: utf-8 -*-
"""
Code modifiable.
"""

from automate import Automate
from state import State
from transition import Transition
from myparser import *

automate = Automate.creationAutomate("exempleAutomate.txt")
#automate.show("exempleAutomate")

automate1 = Automate.creationAutomate("auto1.txt")


automate2 = Automate.creationAutomate("auto2.txt")
#automate2.show("exempleAutomate2")

#test des etats dans l'automate 
print("\n")
print("--------- test des Etats ---------")
s1= State(1, False, False)
s2= State(2, False, False)
print (s1==s2)
print (s1!=s2)
print(automate.listStates)
print("Voici la liste des transitions")
print(automate.getListTransitionsFrom(s1))
print(automate.getListTransitionsFrom(s2))

print("\n")
#test de succElem
print("--------- test succ ---------")
print("Voici la liste des elements successeurs")
print (automate.succ([s1], "a"))
print (automate.succ([s1,s2], "a"))
print (automate.succ([s1], "b"))
print (automate.succ([s2], "a"))
print (automate.succ([s2], "a"))
print (automate.succ([s1], "b"))
print ("\n")


#tests de accepte

print ("L'automate accepte t'il le mot 'aaaa'?")
print (automate.accepte(automate,"aaaa"))
print("--------- test accepte ---------")
print ("L'automate accepte t'il le mot 'abc' ?")
print (automate.accepte(automate,"abc"))
print ("L'automate accepte t'il le mot 'aab' ?")
print (automate.accepte(automate,"aab"))
print ("L'automate accepte t'il le mot 'ab'?")
print (automate.accepte(automate,"ab"))
print ("L'automate accepte t'il le mot 'aaaa'?")
print (automate.accepte(automate,"aaaa"))
print ("L'automate1 accepte t'il le mot 'aaaa'?")
print (automate1.accepte(automate1,"aaaa"))

print ("\n")


#tests est Complet 
print("--------- test estComplet ---------")
print ("L'automate est t'il complet ?")
print (automate.estComplet(automate,"ab"))
print ("\n")

#tests est Deterministe
print("--------- test estDeterministe ---------")
print("L'automate est t'il deterministe ?")
print(automate.estDeterministe(automate))
print(automate1.estDeterministe(automate1))
print(automate2.estDeterministe(automate2))
print ("\n")

#test de CompleteAutomate 
print("--------- CompleteAutomate ---------")
print("Voici l'automate complété ")
print(automate1.completeAutomate(automate1,"ab"))
automate1.show("exempleAutomate1")
auto1complet = Automate.creationAutomate("auto1complet.txt")
auto1complet.show("auto1complet")
print ("\n")


#test de determinisation
print("--------- AutomateDeterminiser ---------")
print("Voici l'automate determiniser ")
print(automate1.determinisation(automate1))
autodeterminiser = Automate.creationAutomate("auto1determiniser.txt")
autodeterminiser.show("auto1determiniser.txt")
print ("\n")

#test de complementaire automate
print("--------- AutomateComplementaire ---------")
print("Voici l'automate complementaire ")
print(automate1.complementaire(automate1, "ab"))
autocomplementaire = Automate.creationAutomate("auto1complementaire.txt")
autocomplementaire.show("auto1complementaire")
print("\n")

#test de l'intersection entre les automates
print("--------- AutomateIntersection ---------")
print("Voici l'intersection entre les automates ")
print(automate.intersection(automate1,automate2))
autointersection = Automate.creationAutomate("auto12inter.txt")
autointersection.show("auto12inter")
print("\n")

#test de la concatenation entre les automates
print("--------- AutomateConcatener ---------")
print("Voici le résultats des automates concatener ")
print(automate.concatenation(automate1,automate2))
autoconcatener = Automate.creationAutomate("auto12concatener.txt")
autoconcatener.show("auto12concatener")