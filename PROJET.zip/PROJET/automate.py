

# -*- coding: utf-8 -*-
from transition import *
from state import *
import os
import copy
from itertools import product
from automateBase import AutomateBase



class Automate(AutomateBase):

    def succElem(self, state, lettre):
        """State x str -> list[State]
        rend la liste des états accessibles à partir d'un état
        state par l'étiquette lettre
        """
        successeurs = []
        # t: Transitions
        for t in self.getListTransitionsFrom(state):
            if t.etiquette == lettre and t.stateDest not in successeurs:
                successeurs.append(t.stateDest)
        return successeurs


    def succ (self, listStates, lettre):
        """list[State] x str -> list[State]
        rend la liste des états accessibles à partir de la liste d'états
        listStates par l'étiquette lettre
        """
        listEtatSucc = []
        #t : Transition
        for t in listStates: #parcours de la liste d'etats
            for s in self.succElem(t,lettre): #parcours des succcesseur
                listEtatSucc.append(s)
        return listEtatSucc


    """ Définition d'une fonction déterminant si un mot est accepté par un automate.
    Exemple :
            a=Automate.creationAutomate("monAutomate.txt")
            if Automate.accepte(a,"abc"):
                print "L'automate )succElem()Succaccepte le mot abc"
            else:
                print "L'automate n'accepte pas le mot abc"
    """
    @staticmethod
    def accepte(auto,mot) :
        """ Automate a str -> bool
        rend True si auto accepte mot, False sinon
        """
        #ls: liste(State)
        ls=auto.getListInitialStates()
        # c: str
        for c in mot:
            ls=auto.succ(ls,c)
            if ls==[]:
                return False
        if State.isFinalIn(ls):
            return True
        return False
        

    @staticmethod
    def estComplet(auto,alphabet) :
        """ Automate x str -> bool
         rend True si auto est complet pour alphabet, False sinon
        """
        LEtat = auto.listStates
        for s in LEtat: 
            for lettre in alphabet: 
                if(auto.succElem(s,lettre) == []):
                    return False
        return True
    

    @staticmethod
    def estDeterministe(auto) :
        """Automate -> bool
        rend True si l'automate est deterministe. False sinon"""
        LEtat = auto.listStates
        for s in LEtat:
            etiset = set()
            LTransition = auto.getListTransitionsFrom(s)
            for t in LTransition:
                if t.etiquette in etiset:
                    return False
                else:
                    etiset.add(t.etiquette)
        return True 



    @staticmethod
    def completeAutomate(auto,alphabet) :
        """ Automate x str -> Automate
        rend l'automate complété d'auto, par rapport à alphabet
        """

        autocomplete = copy.deepcopy(auto)

        if Automate.estComplet(autocomplete,alphabet):
            return autocomplete
        puits : State = State(len(autocomplete.listStates),False,False)

        for s in autocomplete.listStates:
            for c in alphabet:
                if autocomplete.succElem(s,c) == []:
                    autocomplete.addTransition(Transition(s,c,puits))
        return autocomplete



    @staticmethod
    def determinisation(auto) :
        """ Automate  -> Automate
        rend l'automate déterminisé d'auto
        """
        # aut: automate
        aut=Automate([])
        # ens: set(state)
        ens=set()
        # ls: List(state)
        ls=[]
        # dico: Dict[state,List(state)]
        dico=dict()
        # nxt: Liste(state)   liste d'états associés au nouvel état (nxt de 1_0 = [1,0]) 
        nxt=auto.getListInitialStates()
        # snext: state   nouvel état
        snxt=False
        for s in nxt:
            if snxt:
                snxt.insertPrefix(s.id)
            else:
                snxt=State(s.id,True,State.isFinalIn(nxt))
        dico[snxt]=nxt
        ls.append(snxt)
        while len(ls)!=0:
            # spre: state   nouvel état précédent
            spre=ls[len(ls)-1]
            # pre: List(state)   liste des états précédent
            pre=dico[spre]
            # c: str
            for c in auto.getAlphabetFromTransitions():
                nxt=auto.succ(pre,c)
                if nxt!=[]:
                    snxt=False
                    for s in set(nxt):
                        if snxt:
                            snxt.insertPrefix(s.id)
                        else:
                            snxt=State(s.id,False,State.isFinalIn(nxt))
                    if snxt not in ens:
                        # t:transition
                        t=Transition(spre,c,snxt)
                        aut.addTransition(t)
                        dico[snxt]=nxt
                        ls.append(snxt)
                    else:
                        # t:transition
                        t=Transition(spre,c,snxt)
                        aut.addTransition(t)
            ls.remove(spre)
            ens.add(spre)
        return aut

    @staticmethod
    def complementaire(auto,alphabet):
        """ Automate -> Automate
        rend  l'automate acceptant pour langage le complémentaire du langage de a
        """
        #par definition mathematique, si l'automate n'est pas deterministe ou complet alors il faut le faire
        if Automate.estDeterministe(auto):
            autocomplementaire = Automate.completeAutomate(auto,alphabet)
        else:
            autocomplementaire = Automate.determinisation(auto)
            autocomplementaire = Automate.completeAutomate(autocomplementaire,alphabet)

        for s in autocomplementaire.listStates:
            if s.fin: 
                s.fin = False
            else:
                s.fin = True
        return autocomplementaire


    @staticmethod
    def intersection (auto0, auto1):
        """ Automate x Automate -> Automate
        rend l'automate acceptant pour langage l'intersection des langages des deux automates
        """
        # aut: automate
        aut=Automate([])
        for a in [auto0,auto1]:
            if Automate.estDeterministe(a):
                a=Automate.completeAutomate(a,a.getAlphabetFromTransitions())
            else:
                a=Automate.determinisation(a)
                a=Automate.completeAutomate(a,a.getAlphabetFromTransitions())
        
        # ls: List(State)
        ls=[]
        # dico: Dict[state,List(State)]
        dico=dict()
        l0=auto0.getListInitialStates()
        l1=auto1.getListInitialStates()
        L = list(product(l0, l1))
        
        for l in L:         # création des états initiaux
            # spre: State
            s0=State(l[1].id,True,(l[0].fin)and(l[1].fin))
            s0.insertPrefix(l[0].id)
            dico[s0]=l
            ls.append(s0)
        
        for spre in ls:
            for c in auto0.getAlphabetFromTransitions():
                # lnxt0: State
                # lnxt1: State
                lnxt0=auto0.succElem(dico[spre][0], c)
                lnxt1=auto1.succElem(dico[spre][1], c)
                
                if(lnxt0 and lnxt1):
                    L = list(product(lnxt0, lnxt1))
                    
                    for l in L:         # création du prochain état et de la transition avec l'état précédent
                        # snxt: State       
                        snxt=State(l[1].id,False,(l[0].fin)and(l[1].fin))
                        snxt.insertPrefix(l[0].id)
                        dico[snxt]=l
                        if not snxt in ls:
                            ls.append(snxt)
                        # t: Transition
                        t=Transition(spre, c, snxt)
                        aut.addTransition(t)
        return aut

    @staticmethod
    def union (auto0, auto1):
        """ Automate x Automate -> Automate
        rend l'automate acceptant pour langage l'union des langages des deux automates
        """
        return


    @staticmethod
    def concatenation (auto1, auto2):
        """ Automate x Automate -> Automate
        rend l'automate acceptant pour langage la concaténation des langages des deux automates
        """
        for a in [auto1,auto2]:
            if Automate.estDeterministe(a):
                a=Automate.completeAutomate(a,a.getAlphabetFromTransitions())
            else:
                a=Automate.determinisation(a)
                a=Automate.completeAutomate(a,a.getAlphabetFromTransitions())
        # aut: automate
        aut=Automate([])
        # ls: List(State)
        ls=[]
        # linit: List(State)        liste des nouveuax états initiaux correspondant à ceux de auto2
        linit=[]
        # dico: Dict[state,List(State)]
        dico1=dict()
        dico2=dict()
        for s in auto1.listStates:
            if not s.fin:
                # snew: State           nouveaux états
                snew=State(s.id, s.init, False)
                snew.insertPrefix(1)
                dico1[s]=snew
                ls.append(snew)
            
        for s in auto2.listStates:
            # snew: State           nouveaux états
            snew=State(s.id, False, s.fin)
            snew.insertPrefix(2)
            dico2[s]=snew
            ls.append(snew)
            if s.init:
                linit.append(snew)
                
        # snxt: List(State)
        for s in auto1.listStates:          #création des transisions correspondant à celle de auto1 et des transitions entre auto1 et auto2
            for c in auto1.getAlphabetFromTransitions():
                snxt=auto1.succElem(s,c)
                for sn in snxt:
                    if sn.fin:
                        for sinit in linit:
                            if s.fin:           #cas où état1 et état2 sont finaux donc la transition se fait d'un état initial à un autre état initial de auto2
                                for sinit2 in linit:
                                    aut.addTransition(Transition(sinit, c, sinit2))
                            else:           #cas où état2 est final donc la transition se fait de l'état1 à un état initial de auto2
                                aut.addTransition(Transition(dico1[s], c, sinit))
                    elif not s.fin:             #cas où état1 et état2 ne sont pas des états finaux (cas normale)
                        aut.addTransition(Transition(dico1[s], c, dico1[sn]))
                    else:           #cas où état1 est final donc la transition se fait d'un état initial de auto2 à l'état2
                        for sinit in linit:
                            aut.addTransition(Transition(sinit, c, dico1[sn]))
                    
        for s in auto2.listStates:          #céation des transitions correspondant à celle de auto2
            for c in auto2.getAlphabetFromTransitions():
                snxt=auto2.succElem(s,c)
                for sn in snxt:
                    aut.addTransition(Transition(dico2[s], c, dico2[sn]))
                
        return aut

    @staticmethod
    def etoile (auto):
        """ Automate  -> Automate
        rend l'automate acceptant pour langage l'étoile du langage de a
        """
        return
